import React, { Component } from "react";
import FirstPage from "./view/firstPage";

class App extends Component {
  render() {
    return (
      <>
        <FirstPage />
      </>
    );
  }
}

export default App;
