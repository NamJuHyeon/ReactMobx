import React, { Component } from "react";

class megaDeveloperModalView extends Component {
  render() {
    return <div></div>;
  }
}

export default megaDeveloperModalView;
