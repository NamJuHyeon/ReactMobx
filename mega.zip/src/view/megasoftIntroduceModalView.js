import React, { Component } from "react";

class megasoftIntroduceModalView extends Component {
  render() {
    return <div></div>;
  }
}

export default megasoftIntroduceModalView;
