import react, { Component } from "react";
axios({
  method: "get",
  url: "url",
  responseType: "type",
}).then(function (response) {
  // response Action
});
